# PocketVR (Android, Kotlin)
Нативный проект: OpenGL ES 2.0 стерео-рендер, CameraX + MediaPipe HandLandmarker, фильтр 1€, гироскоп/акселерометр/6DoF, MR с камерой.

## Как получить APK без ПК
1. Создай репозиторий на GitHub, залей туда содержимое этой папки.
2. Вкладка Actions → build-apk → Run workflow (сборка запускается и сама на push).
3. Когда закончится, внизу страницы запуска скачай артефакт PocketVR-debug-apk, внутри .apk.

## Через Android Studio
Открой папку, скачай модель в app/src/main/assets/hand_landmarker.task:
https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
и жми Run.
