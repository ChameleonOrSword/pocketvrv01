plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{
 namespace="com.pocketvr.app";compileSdk=34
 defaultConfig{applicationId="com.pocketvr.app";minSdk=26;targetSdk=34;versionCode=1;versionName="0.1"}
 compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
 kotlinOptions{jvmTarget="17"}
 androidResources{noCompress+="task"}
}
dependencies{
 val c="1.3.4"
 implementation("androidx.camera:camera-core:$c");implementation("androidx.camera:camera-camera2:$c");implementation("androidx.camera:camera-lifecycle:$c")
 implementation("com.google.mediapipe:tasks-vision:0.10.14")
 implementation("androidx.appcompat:appcompat:1.7.0")
}
