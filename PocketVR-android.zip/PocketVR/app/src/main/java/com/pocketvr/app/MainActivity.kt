package com.pocketvr.app
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity:AppCompatActivity(){
 private var pending:Class<*>?=null
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 private val AC=0xFF19F0FF.toInt();private val AC2=0xFFFF3DF2.toInt();private val BG=0xFF04050D.toInt();private val CARD=0xFF0E1330.toInt()
 private fun lp(t:Int=-1)=LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(t)}

 override fun onCreate(b:Bundle?){super.onCreate(b);Prefs.init(this);window.statusBarColor=BG
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(28),dp(18),dp(40))}
  root.addView(TextView(this).apply{text="PocketVR";textSize=36f;setTextColor(AC);typeface=Typeface.DEFAULT_BOLD})
  root.addView(TextView(this).apply{text="VR на телефоне: ночной грид, руки через камеру";setTextColor(0x99DFF6FF.toInt())})
  root.addView(big("▶ Запустить VR",AC){go(VrActivity::class.java)},lp(18))
  root.addView(big("🖐 Тест трекинга",AC2){go(TestActivity::class.java)},lp(8))
  seg(root,"Режим","mode",listOf("VR","MR (камера)"))
  seg(root,"Отслеживание головы","track",listOf("Гироскоп","Акселерометр","6DoF (эксп.)"))
  seg(root,"Модель рук","hand",listOf("Неон","Кубы","Призрак","Робот"))
  seg(root,"Блоки","shape",listOf("Куб","Шар","Микс"))
  seg(root,"Камера трекинга","cam",listOf("Задняя","Фронтальная"))
  seg(root,"Турбо-буст (GPU + низкое разрешение)","turbo",listOf("Выкл","Вкл"))
  seg(root,"Зеркалить руки","mirror",listOf("Выкл","Вкл"))
  slider(root,"Антидрожь","smooth",0,100);slider(root,"Поле зрения (FOV)","fov",50,110);slider(root,"Расстояние между глазами, мм","ipd",50,75)
  root.addView(TextView(this).apply{text="В VR: тап — блок, удержание — убрать все, два пальца — центр, щипок пальцами — схватить блок.";setTextColor(0x99DFF6FF.toInt())},lp(16))
  setContentView(ScrollView(this).apply{setBackgroundColor(BG);addView(root)})}

 private fun big(t:String,c:Int,f:()->Unit)=Button(this).apply{text=t;textSize=18f;setTextColor(Color.WHITE);setBackgroundColor(CARD);setPadding(0,dp(16),0,dp(16));setOnClickListener{f()}}
 private fun card(root:LinearLayout,title:String):LinearLayout{val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(0xFF0B1028.toInt());setPadding(dp(12),dp(10),dp(12),dp(12))}
  l.addView(TextView(this).apply{text=title;setTextColor(0xB3DFF6FF.toInt());textSize=13f});root.addView(l,lp(10));return l}
 private fun seg(root:LinearLayout,title:String,key:String,opts:List<String>){val c=card(root,title);val row=LinearLayout(this);val bs=ArrayList<Button>()
  fun paint(){bs.forEachIndexed{i,b->val on=Prefs[key]==i;b.setBackgroundColor(if(on)AC else CARD);b.setTextColor(if(on)0xFF022211.toInt() else Color.WHITE)}}
  opts.forEachIndexed{i,t->val b=Button(this).apply{text=t;isAllCaps=false;setOnClickListener{Prefs[key]=i;paint()}};bs.add(b);row.addView(b,LinearLayout.LayoutParams(0,-2,1f).apply{marginEnd=dp(4)})}
  paint();c.addView(row)}
 private fun slider(root:LinearLayout,title:String,key:String,mn:Int,mx:Int){val c=card(root,"$title: ${Prefs[key]}")
  val sb=SeekBar(this).apply{max=mx-mn;progress=Prefs[key]-mn;setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
   override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){Prefs[key]=p+mn;(c.getChildAt(0) as TextView).text="$title: ${p+mn}"}
   override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){}})};c.addView(sb)}

 private fun go(c:Class<*>){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startActivity(Intent(this,c))
  else{pending=c;ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),1)}}
 override fun onRequestPermissionsResult(rc:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(rc,p,g)
  if(g.isNotEmpty()&&g[0]==PackageManager.PERMISSION_GRANTED)pending?.let{startActivity(Intent(this,it))} else Toast.makeText(this,"Нужен доступ к камере",Toast.LENGTH_LONG).show()}
}
