package com.pocketvr.app
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.FloatBuffer
import java.util.Random
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class Block(val mesh:Int,val size:Float,val col:FloatArray){val p=FloatArray(3);val v=FloatArray(3);var h=-1}
class Draw(val m:Mesh,val model:FloatArray,val c:FloatArray,val emis:Float)
class Sty(val c:Int,val j:Float,val b:Float,val s:Boolean,val o:Float)
val STY=arrayOf(Sty(0x19f0ff,.008f,.003f,true,1f),Sty(0xff3df2,.011f,.009f,false,1f),Sty(0x7dff9a,.014f,.002f,true,.35f),Sty(0xffa21a,.010f,.007f,true,1f))
val CONN=arrayOf(0 to 1,1 to 2,2 to 3,3 to 4,0 to 5,5 to 6,6 to 7,7 to 8,5 to 9,9 to 10,10 to 11,11 to 12,9 to 13,13 to 14,14 to 15,15 to 16,13 to 17,17 to 18,18 to 19,19 to 20,0 to 17)
fun rgb(c:Int,a:Float=1f)=floatArrayOf((c shr 16 and 255)/255f,(c shr 8 and 255)/255f,(c and 255)/255f,a)

class VrRenderer(val a:VrActivity):GLSurfaceView.Renderer{
 var onReady:()->Unit={}
 var pr=0;var pc=0;var uMVP=0;var uM=0;var uC=0;var uLit=0;var uEmis=0;var uFog=0;var aP=0;var aN=0
 var cTM=0;var cRx=0;var cMir=0;var cP=0
 lateinit var cube:Mesh;lateinit var sph:Mesh
 lateinit var g1:FloatBuffer;lateinit var g2:FloatBuffer;lateinit var stars:FloatBuffer;lateinit var quad:FloatBuffer
 var n1=0;var n2=0;var camTex=0;var st:SurfaceTexture?=null;val tm=FloatArray(16).also{Matrix.setIdentityM(it,0)}
 var W=2;var H=1;var lastT=System.nanoTime()
 val blocks=ArrayList<Block>()
 @Volatile var hands:List<Hand> = emptyList();@Volatile var handAr=1.33f
 val pos=FloatArray(3);val vel=FloatArray(3);@Volatile var yawOff=0f
 val Ms=floatArrayOf(1f,0f,0f,0f,1f,0f,0f,0f,1f);var M=Ms.copyOf();val accS=floatArrayOf(0f,0f,9.8f)
 val hp=Array(2){Array(21){FloatArray(3)}};val vis=BooleanArray(2);val pinch=BooleanArray(2);val held=arrayOfNulls<Block>(2)
 val pp=Array(2){FloatArray(3)};val pv=Array(2){FloatArray(3)}
 val pill=ArrayList<FloatArray>()

 private fun sh(t:Int,s:String):Int{val i=GLES20.glCreateShader(t);GLES20.glShaderSource(i,s);GLES20.glCompileShader(i);return i}
 private fun prog(v:String,f:String):Int{val p=GLES20.glCreateProgram();GLES20.glAttachShader(p,sh(GLES20.GL_VERTEX_SHADER,v));GLES20.glAttachShader(p,sh(GLES20.GL_FRAGMENT_SHADER,f));GLES20.glLinkProgram(p);return p}

 override fun onSurfaceCreated(g:GL10?,c:EGLConfig?){
  pr=prog("attribute vec3 aP;attribute vec3 aN;uniform mat4 uMVP;uniform mat4 uM;varying vec3 vN;varying float vD;void main(){gl_Position=uMVP*vec4(aP,1.);vN=(uM*vec4(aN,0.)).xyz;vD=gl_Position.w;gl_PointSize=2.;}",
   "precision mediump float;uniform vec4 uC;uniform float uLit;uniform float uEmis;uniform float uFog;varying vec3 vN;varying float vD;void main(){vec3 c=uC.rgb;if(uLit>.5){float d=max(dot(normalize(vN),normalize(vec3(.3,.8,.4))),0.);c=c*(.3+.7*d)+uC.rgb*uEmis;}float f=uFog>.5?clamp((vD-12.)/108.,0.,1.):0.;c=mix(c,vec3(.012,.012,.05),f);gl_FragColor=vec4(c,uC.a);}")
  uMVP=GLES20.glGetUniformLocation(pr,"uMVP");uM=GLES20.glGetUniformLocation(pr,"uM");uC=GLES20.glGetUniformLocation(pr,"uC");uLit=GLES20.glGetUniformLocation(pr,"uLit")
  uEmis=GLES20.glGetUniformLocation(pr,"uEmis");uFog=GLES20.glGetUniformLocation(pr,"uFog");aP=GLES20.glGetAttribLocation(pr,"aP");aN=GLES20.glGetAttribLocation(pr,"aN")
  pc=prog("attribute vec2 aP;uniform mat4 uTM;uniform float uRx;uniform float uMir;varying vec2 vU;void main(){gl_Position=vec4(aP,0.,1.);vec2 u=aP*.5+.5;u.x=(u.x-.5)*uRx+.5;if(uMir>.5)u.x=1.-u.x;vU=(uTM*vec4(u,0.,1.)).xy;}",
   "#extension GL_OES_EGL_image_external : require\nprecision mediump float;uniform samplerExternalOES uT;varying vec2 vU;void main(){gl_FragColor=texture2D(uT,vU);}")
  cTM=GLES20.glGetUniformLocation(pc,"uTM");cRx=GLES20.glGetUniformLocation(pc,"uRx");cMir=GLES20.glGetUniformLocation(pc,"uMir");cP=GLES20.glGetAttribLocation(pc,"aP")
  cube=cubeMesh();sph=sphereMesh()
  val l1=ArrayList<Float>();for(i in -60..60){l1.addAll(listOf(i.toFloat(),0f,-60f,i.toFloat(),0f,60f,-60f,0f,i.toFloat(),60f,0f,i.toFloat()))};g1=fb(l1.toFloatArray());n1=l1.size/3
  val l2=ArrayList<Float>();for(i in -20..20){val k=i*10f;l2.addAll(listOf(k,.01f,-200f,k,.01f,200f,-200f,.01f,k,200f,.01f,k))};g2=fb(l2.toFloatArray());n2=l2.size/3
  val rnd=Random(7);val sp=FloatArray(1500);for(i in 0 until 500){val an=rnd.nextFloat()*6.283f;val e=.1f+rnd.nextFloat()*1.4f
   sp[i*3]=cos(an)*cos(e)*400;sp[i*3+1]=sin(e)*400;sp[i*3+2]=sin(an)*cos(e)*400};stars=fb(sp)
  quad=fb(floatArrayOf(-1f,-1f,1f,-1f,-1f,1f,1f,1f))
  pill.clear();for(i in 0 until 16){val an=rnd.nextFloat()*6.283f;val r=15+rnd.nextFloat()*50;val h=5+rnd.nextFloat()*10
   pill.add(floatArrayOf(cos(an)*r,sin(an)*r,h,if(rnd.nextBoolean())0x19f0ff.toFloat() else 0xff3df2.toFloat()))}
  val t=IntArray(1);GLES20.glGenTextures(1,t,0);camTex=t[0];GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,camTex)
  GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR)
  st=SurfaceTexture(camTex)
  GLES20.glEnable(GLES20.GL_DEPTH_TEST);GLES20.glEnable(GLES20.GL_BLEND);GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA)
  onReady()}
 override fun onSurfaceChanged(g:GL10?,w:Int,h:Int){W=w;H=h}

 // ---------- голова ----------
 private fun rawM():FloatArray{val o=a.dispRot*PI.toFloat()/2;val c=cos(o);val s=sin(o)
  return if(Prefs["track"]==1){val k=1f-min(.97f,Prefs["smooth"]/105f);for(i in 0..2)accS[i]+=(a.acc[i]-accS[i])*k
   val l=sqrt(accS[0]*accS[0]+accS[1]*accS[1]+accS[2]*accS[2]).coerceAtLeast(1e-3f);val u=floatArrayOf(accS[0]/l,accS[1]/l,accS[2]/l)
   fromTo(floatArrayOf(u[0]*c-u[1]*s,u[0]*s+u[1]*c,u[2]),floatArrayOf(0f,1f,0f))}
  else mul3(ENU2GL,mul3(a.rotM,rotZ(-o)))}
 fun recenter(){val m=rawM();m.copyInto(Ms);yawOff=if(Prefs["track"]==1)0f else -atan2(m[2],m[8]);pos.fill(0f);vel.fill(0f);a.toast("Вид центрирован")}
 private fun head(dt:Float){val m=rawM();val s=Prefs["smooth"]/200f;for(i in 0..8)Ms[i]=Ms[i]*s+m[i]*(1-s);ortho(Ms);M=mul3(rotY(yawOff),Ms)
  if(Prefs["track"]==2){val o=a.dispRot*PI.toFloat()/2;val c=cos(o);val sn=sin(o);val l=a.lin
   val w=mv3(M,floatArrayOf(l[0]*c-l[1]*sn,l[0]*sn+l[1]*c,l[2]));if(sqrt(w[0]*w[0]+w[1]*w[1]+w[2]*w[2])<.25f)w.fill(0f)
   val d1=.2f.pow(dt);val d2=.6f.pow(dt);for(i in 0..2){vel[i]=(vel[i]+w[i]*dt)*d1;pos[i]=(pos[i]+vel[i]*dt)*d2;pos[i]=pos[i].coerceIn(-1.5f,1.5f)}}
  else{pos.fill(0f);vel.fill(0f)}}
 private fun eyeC()=floatArrayOf(pos[0],1.6f+pos[1],pos[2])

 // ---------- руки, щипок, блоки ----------
 private fun drop(h:Int){held[h]?.let{it.h=-1;pv[h].copyInto(it.v)};held[h]=null}
 private fun hands(dt:Float){val hs=hands;val asp=(W/2f)/H;val th=tan(Math.toRadians(Prefs["fov"]/2.0)).toFloat();val ar=handAr;val rx=min(1f,asp/ar);val now=System.currentTimeMillis();val mir=Prefs["mirror"]==1;val ec=eyeC()
  for(h in 0..1){val d=hs.getOrNull(h);vis[h]=d!=null&&now-d.t<200
   if(!vis[h]||d==null){pinch[h]=false;drop(h);continue}
   val L=d.lm;val sz=hypot((L[0]-L[27])*ar,L[1]-L[28]).coerceAtLeast(.02f);val D=(.09f/(sz*2*th)).coerceIn(.2f,1.3f)
   for(i in 0 until 21){val x=if(mir)1f-L[i*3] else L[i*3];val dz=D+L[i*3+2]*ar*2*D*th
    val w=mv3(M,floatArrayOf((x-.5f)/rx*2*th*asp*dz,-(L[i*3+1]-.5f)*2*th*dz,-dz));for(k in 0..2)hp[h][i][k]=ec[k]+w[k]}
   val P=hp[h];val pd=sqrt((P[4][0]-P[8][0]).pow(2)+(P[4][1]-P[8][1]).pow(2)+(P[4][2]-P[8][2]).pow(2))
   if(!pinch[h]&&pd<.03f)pinch[h]=true else if(pinch[h]&&pd>.05f)pinch[h]=false
   val np=floatArrayOf((P[4][0]+P[8][0])/2,(P[4][1]+P[8][1])/2,(P[4][2]+P[8][2])/2)
   val v=FloatArray(3){(np[it]-pp[h][it])/max(dt,.008f)};val vl=sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);val sc=if(vl>6f)6f/vl else 1f
   for(k in 0..2){pv[h][k]=v[k]*sc;pp[h][k]=np[k]}
   if(pinch[h]&&held[h]==null){var best:Block?=null;var bd=.15f
    for(b in blocks)if(b.h<0){val q=sqrt((b.p[0]-np[0]).pow(2)+(b.p[1]-np[1]).pow(2)+(b.p[2]-np[2]).pow(2));if(q<bd){bd=q;best=b}}
    best?.let{it.h=h;held[h]=it;a.buzz()}}
   if(!pinch[h])drop(h)}}
 fun spawn(){val s=Prefs["shape"].let{if(it==2)(0..1).random() else it};val col=Color.HSVToColor(floatArrayOf((0..359).random().toFloat(),1f,1f))
  val b=Block(s,.12f,rgb(col));val w=mv3(M,floatArrayOf(0f,.05f,-.6f));val ec=eyeC();for(k in 0..2)b.p[k]=ec[k]+w[k]
  blocks.add(b);if(blocks.size>80){val o=blocks.removeAt(0);for(i in 0..1)if(held[i]===o)held[i]=null}
  a.toast("Блоков: ${blocks.size}")}
 fun clear(){blocks.clear();held[0]=null;held[1]=null;a.toast("Блоки убраны")}
 private fun phys(dt:Float){for(b in blocks){if(b.h>=0){val t=pp[b.h];for(k in 0..2){b.v[k]=((t[k]-b.p[k])/dt).coerceIn(-8f,8f);b.p[k]=t[k]};continue}
  b.v[1]-=9.8f*dt;for(k in 0..2)b.p[k]+=b.v[k]*dt
  val hs=b.size/2;if(b.p[1]<hs){b.p[1]=hs;b.v[1]*=-.35f;b.v[0]*=.9f;b.v[2]*=.9f;if(abs(b.v[1])<.4f)b.v[1]=0f}}}
 private fun addHand(h:Int,dl:ArrayList<Draw>){val sty=STY[Prefs["hand"]];val P=hp[h];val col=rgb(sty.c,sty.o)
  for(i in 0 until 21){val s=(if(i%4==0)1.4f else 1f)*(if(sty.s)2f else 1.6f)*sty.j;dl.add(Draw(if(sty.s)sph else cube,modelS(P[i],s),col,.6f))}
  for((x,y) in CONN){val A=P[x];val B=P[y];val mid=floatArrayOf((A[0]+B[0])/2,(A[1]+B[1])/2,(A[2]+B[2])/2)
   val d=floatArrayOf(B[0]-A[0],B[1]-A[1],B[2]-A[2]);val len=sqrt(d[0]*d[0]+d[1]*d[1]+d[2]*d[2]);dl.add(Draw(cube,modelDir(mid,d,sty.b,sty.b,len),col,.6f))}}

 // ---------- рисование ----------
 private fun put(m:Mesh,model:FloatArray,vp:FloatArray,c:FloatArray,lit:Float,emis:Float,fog:Float){
  val mvp=FloatArray(16);Matrix.multiplyMM(mvp,0,vp,0,model,0)
  GLES20.glUniformMatrix4fv(uMVP,1,false,mvp,0);GLES20.glUniformMatrix4fv(uM,1,false,model,0);GLES20.glUniform4fv(uC,1,c,0)
  GLES20.glUniform1f(uLit,lit);GLES20.glUniform1f(uEmis,emis);GLES20.glUniform1f(uFog,fog)
  GLES20.glEnableVertexAttribArray(aP);GLES20.glEnableVertexAttribArray(aN)
  GLES20.glVertexAttribPointer(aP,3,GLES20.GL_FLOAT,false,24,m.vb.apply{position(0)});GLES20.glVertexAttribPointer(aN,3,GLES20.GL_FLOAT,false,24,m.vb.apply{position(3)})
  GLES20.glDrawElements(GLES20.GL_TRIANGLES,m.n,GLES20.GL_UNSIGNED_SHORT,m.ib)}
 private fun lines(b:FloatBuffer,n:Int,mode:Int,vp:FloatArray,c:FloatArray,fog:Float){val id=FloatArray(16);Matrix.setIdentityM(id,0)
  GLES20.glUniformMatrix4fv(uMVP,1,false,vp,0);GLES20.glUniformMatrix4fv(uM,1,false,id,0);GLES20.glUniform4fv(uC,1,c,0);GLES20.glUniform1f(uLit,0f);GLES20.glUniform1f(uFog,fog)
  GLES20.glDisableVertexAttribArray(aN);GLES20.glVertexAttrib3f(aN,0f,1f,0f);GLES20.glEnableVertexAttribArray(aP);GLES20.glVertexAttribPointer(aP,3,GLES20.GL_FLOAT,false,12,b.apply{position(0)})
  GLES20.glDrawArrays(mode,0,n)}
 private fun drawCam(rx:Float){GLES20.glDisable(GLES20.GL_DEPTH_TEST);GLES20.glUseProgram(pc);GLES20.glUniformMatrix4fv(cTM,1,false,tm,0);GLES20.glUniform1f(cRx,rx);GLES20.glUniform1f(cMir,if(Prefs["mirror"]==1)1f else 0f)
  GLES20.glEnableVertexAttribArray(cP);GLES20.glVertexAttribPointer(cP,2,GLES20.GL_FLOAT,false,8,quad.apply{position(0)});GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4);GLES20.glEnable(GLES20.GL_DEPTH_TEST)}

 override fun onDrawFrame(g:GL10?){
  val now=System.nanoTime();val dt=min(.05f,(now-lastT)/1e9f).coerceAtLeast(.001f);lastT=now;val mr=Prefs["mode"]==1
  st?.let{try{it.updateTexImage();it.getTransformMatrix(tm)}catch(e:Exception){}}
  head(dt);hands(dt);phys(dt)
  val dl=ArrayList<Draw>();for(b in blocks)dl.add(Draw(if(b.mesh==0)cube else sph,modelS(b.p,b.size),b.col,.35f));for(h in 0..1)if(vis[h])addHand(h,dl)
  val asp=(W/2f)/H;val rx=min(1f,asp/handAr);val ipd=Prefs["ipd"]/2000f;val fog=if(mr)0f else 1f;val ec=eyeC()
  GLES20.glEnable(GLES20.GL_SCISSOR_TEST)
  for(e in 0..1){val x0=e*(W/2);GLES20.glViewport(x0,0,W/2,H);GLES20.glScissor(x0,0,W/2,H)
   GLES20.glClearColor(.012f,.012f,.05f,1f);GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
   if(mr)drawCam(rx)
   val sg=if(e==0)-1f else 1f;val eye=floatArrayOf(ec[0]+M[0]*sg*ipd,ec[1]+M[3]*sg*ipd,ec[2]+M[6]*sg*ipd)
   val view=FloatArray(16);for(r in 0..2){for(c in 0..2)view[c*4+r]=M[c*3+r];view[12+r]=-(M[r]*eye[0]+M[3+r]*eye[1]+M[6+r]*eye[2])};view[15]=1f
   val pj=FloatArray(16);Matrix.perspectiveM(pj,0,Prefs["fov"].toFloat(),asp,.02f,500f);val vp=FloatArray(16);Matrix.multiplyMM(vp,0,pj,0,view,0)
   GLES20.glUseProgram(pr)
   if(!mr){put(cube,modelS(floatArrayOf(0f,-.05f,0f),400f,.1f,400f),vp,floatArrayOf(.015f,.024f,.1f,1f),0f,0f,fog)
    lines(g1,n1,GLES20.GL_LINES,vp,floatArrayOf(.05f,.16f,.55f,1f),fog);lines(g2,n2,GLES20.GL_LINES,vp,floatArrayOf(.1f,.94f,1f,1f),fog)
    lines(stars,500,GLES20.GL_POINTS,vp,floatArrayOf(1f,1f,1f,1f),0f)
    for(p in pill){put(cube,modelS(floatArrayOf(p[0],p[2]/2,p[1]),1f,p[2],1f),vp,rgb(p[3].toInt()),1f,.8f,fog)}}
   for(d in dl)put(d.m,d.model,vp,d.c,1f,d.emis,fog)}
  GLES20.glDisable(GLES20.GL_SCISSOR_TEST)}
}
