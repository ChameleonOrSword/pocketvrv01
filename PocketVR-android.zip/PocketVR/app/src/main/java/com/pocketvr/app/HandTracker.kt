package com.pocketvr.app
import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Size
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.Executors
import kotlin.math.*

/** lm/raw: 21 точка x,y,z (нормированные), lm сглажен фильтром 1€ */
class Hand(val lm:FloatArray,val raw:FloatArray,val t:Long)
class OE{var x=Float.NaN;var dx=0f;var t=0L
 fun f(v:Float,now:Long,mc:Float,b:Float):Float{
  if(x.isNaN()){x=v;t=now;return v}
  val dt=max(1e-3f,(now-t)/1000f);t=now
  fun a(c:Float):Float{val r=(2*PI*c*dt).toFloat();return r/(r+1)}
  dx+=a(1f)*((v-x)/dt-dx);x+=a(mc+b*abs(dx))*(v-x);return x}}

class HandTracker(val act:Activity,val onHands:(List<Hand>,Float,Bitmap?)->Unit){
 var fps=0f;var lat=0f;private var lastT=0L
 private var lm:HandLandmarker?=null
 private val exec=Executors.newSingleThreadExecutor()
 private val filt=Array(2){Array(63){OE()}}
 private var prov:ProcessCameraProvider?=null

 private fun build(gpu:Boolean)=HandLandmarker.createFromOptions(act,HandLandmarker.HandLandmarkerOptions.builder()
  .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").setDelegate(if(gpu)Delegate.GPU else Delegate.CPU).build())
  .setRunningMode(RunningMode.VIDEO).setNumHands(2).build())

 fun start(owner:LifecycleOwner,rot:Int,preview:Preview?,wantFrame:Boolean){
  val turbo=Prefs["turbo"]==1
  val f=ProcessCameraProvider.getInstance(act)
  f.addListener({
   val p=f.get();prov=p
   val sel=if(Prefs["cam"]==1)CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
   val an=ImageAnalysis.Builder().setTargetResolution(if(turbo)Size(320,240) else Size(640,480)).setTargetRotation(rot)
    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()
   an.setAnalyzer(exec){ip->analyze(ip,wantFrame,turbo)}
   p.unbindAll()
   if(preview!=null)p.bindToLifecycle(owner,sel,preview,an) else p.bindToLifecycle(owner,sel,an)
  },ContextCompat.getMainExecutor(act))}

 fun stop(){prov?.unbindAll();exec.execute{lm?.close();lm=null}}

 private fun analyze(ip:ImageProxy,want:Boolean,turbo:Boolean){
  val t0=System.nanoTime()
  try{
   val src=ip.toBitmap();val m=Matrix();m.postRotate(ip.imageInfo.rotationDegrees.toFloat())
   val b=Bitmap.createBitmap(src,0,0,src.width,src.height,m,true)
   val L=lm?:(try{build(turbo)}catch(e:Throwable){build(false)}).also{lm=it}
   val r=L.detectForVideo(BitmapImageBuilder(b).build(),ip.imageInfo.timestamp/1000000)
   val now=System.currentTimeMillis();val mc=.3f+8f*(1f-Prefs["smooth"]/100f).pow(2)
   val out=r.landmarks().take(2).mapIndexed{i,l->
    val raw=FloatArray(63);val sm=FloatArray(63)
    l.forEachIndexed{j,p->val a=floatArrayOf(p.x(),p.y(),p.z());for(k in 0..2){raw[j*3+k]=a[k];sm[j*3+k]=filt[i][j*3+k].f(a[k],now,mc,2f)}}
    Hand(sm,raw,now)}
   if(out.isEmpty())filt.forEach{f->f.forEach{o->o.x=Float.NaN}}
   lat=(System.nanoTime()-t0)/1e6f;fps=fps*.9f+.1f*(1000f/max(1f,(now-lastT).toFloat()));lastT=now
   onHands(out,b.width.toFloat()/b.height,if(want)b else null)
  }catch(e:Throwable){}finally{ip.close()}}
}
