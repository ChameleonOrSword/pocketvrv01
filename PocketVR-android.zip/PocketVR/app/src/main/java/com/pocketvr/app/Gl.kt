package com.pocketvr.app
import java.nio.*
import kotlin.math.*

class Mesh(vtx:FloatArray,idx:ShortArray){
 val vb:FloatBuffer=ByteBuffer.allocateDirect(vtx.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(vtx);position(0)}
 val ib:ShortBuffer=ByteBuffer.allocateDirect(idx.size*2).order(ByteOrder.nativeOrder()).asShortBuffer().apply{put(idx);position(0)}
 val n=idx.size}
fun fb(a:FloatArray):FloatBuffer=ByteBuffer.allocateDirect(a.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(a);position(0)}

fun cubeMesh():Mesh{val v=ArrayList<Float>();val ix=ArrayList<Short>()
 val ns=arrayOf(floatArrayOf(1f,0f,0f),floatArrayOf(-1f,0f,0f),floatArrayOf(0f,1f,0f),floatArrayOf(0f,-1f,0f),floatArrayOf(0f,0f,1f),floatArrayOf(0f,0f,-1f))
 for(n in ns){val u=if(n[1]!=0f)floatArrayOf(1f,0f,0f) else floatArrayOf(0f,1f,0f)
  val w=floatArrayOf(n[1]*u[2]-n[2]*u[1],n[2]*u[0]-n[0]*u[2],n[0]*u[1]-n[1]*u[0]);val b=v.size/6
  for((s,t) in listOf(-1 to -1,1 to -1,1 to 1,-1 to 1)){for(k in 0..2)v.add(.5f*(n[k]+s*u[k]+t*w[k]));for(k in 0..2)v.add(n[k])}
  for(i in intArrayOf(0,1,2,0,2,3))ix.add((b+i).toShort())}
 return Mesh(v.toFloatArray(),ix.toShortArray())}
fun sphereMesh():Mesh{val v=ArrayList<Float>();val ix=ArrayList<Short>();val la=8;val lo=12
 for(i in 0..la){val th=PI*i/la;for(j in 0..lo){val ph=2*PI*j/lo
  val x=(sin(th)*cos(ph)).toFloat();val y=cos(th).toFloat();val z=(sin(th)*sin(ph)).toFloat();v.addAll(listOf(x*.5f,y*.5f,z*.5f,x,y,z))}}
 for(i in 0 until la)for(j in 0 until lo){val a=i*(lo+1)+j;val b=a+lo+1
  ix.addAll(listOf(a.toShort(),b.toShort(),(a+1).toShort(),(a+1).toShort(),b.toShort(),(b+1).toShort()))}
 return Mesh(v.toFloatArray(),ix.toShortArray())}

// 3x3 row-major
fun mul3(a:FloatArray,b:FloatArray)=FloatArray(9).also{for(i in 0..2)for(j in 0..2)it[i*3+j]=a[i*3]*b[j]+a[i*3+1]*b[3+j]+a[i*3+2]*b[6+j]}
fun mv3(a:FloatArray,v:FloatArray)=floatArrayOf(a[0]*v[0]+a[1]*v[1]+a[2]*v[2],a[3]*v[0]+a[4]*v[1]+a[5]*v[2],a[6]*v[0]+a[7]*v[1]+a[8]*v[2])
fun rotZ(t:Float)=floatArrayOf(cos(t),-sin(t),0f,sin(t),cos(t),0f,0f,0f,1f)
fun rotY(t:Float)=floatArrayOf(cos(t),0f,sin(t),0f,1f,0f,-sin(t),0f,cos(t))
val ENU2GL=floatArrayOf(1f,0f,0f,0f,0f,1f,0f,-1f,0f)
fun fromTo(a:FloatArray,b:FloatArray):FloatArray{
 val v=floatArrayOf(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]);val c=a[0]*b[0]+a[1]*b[1]+a[2]*b[2];val k=1f/(1f+max(c,-.99f))
 val vx=floatArrayOf(0f,-v[2],v[1],v[2],0f,-v[0],-v[1],v[0],0f);val vx2=mul3(vx,vx)
 return FloatArray(9){(if(it%4==0)1f else 0f)+vx[it]+vx2[it]*k}}
fun ortho(m:FloatArray){var x=floatArrayOf(m[0],m[3],m[6]);var y=floatArrayOf(m[1],m[4],m[7])
 fun n(a:FloatArray){val l=sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]).coerceAtLeast(1e-6f);a[0]/=l;a[1]/=l;a[2]/=l}
 n(x);val d=x[0]*y[0]+x[1]*y[1]+x[2]*y[2];y=floatArrayOf(y[0]-d*x[0],y[1]-d*x[1],y[2]-d*x[2]);n(y)
 val z=floatArrayOf(x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0])
 for(r in 0..2){m[r*3]=x[r];m[r*3+1]=y[r];m[r*3+2]=z[r]}}
// 4x4 column-major модели
fun modelS(p:FloatArray,sx:Float,sy:Float=sx,sz:Float=sx)=FloatArray(16).also{it[0]=sx;it[5]=sy;it[10]=sz;it[15]=1f;it[12]=p[0];it[13]=p[1];it[14]=p[2]}
fun modelDir(p:FloatArray,d:FloatArray,sx:Float,sy:Float,sz:Float):FloatArray{
 val l=sqrt(d[0]*d[0]+d[1]*d[1]+d[2]*d[2]);if(l<1e-6f)return modelS(p,0f)
 val z=floatArrayOf(d[0]/l,d[1]/l,d[2]/l);var x=floatArrayOf(z[2],0f,-z[0]) // up(0,1,0) x z
 if(abs(x[0])+abs(x[2])<1e-3f)x=floatArrayOf(1f,0f,0f)
 val xl=sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]);x=floatArrayOf(x[0]/xl,x[1]/xl,x[2]/xl)
 val y=floatArrayOf(z[1]*x[2]-z[2]*x[1],z[2]*x[0]-z[0]*x[2],z[0]*x[1]-z[1]*x[0])
 val m=FloatArray(16);for(i in 0..2){m[i]=x[i]*sx;m[4+i]=y[i]*sy;m[8+i]=z[i]*sz;m[12+i]=p[i]};m[15]=1f;return m}
