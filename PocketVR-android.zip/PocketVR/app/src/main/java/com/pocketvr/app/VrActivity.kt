package com.pocketvr.app
import android.hardware.*
import android.opengl.GLSurfaceView
import android.os.*
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Preview
import androidx.core.content.ContextCompat
import androidx.core.view.*
import kotlin.math.abs

class VrActivity:AppCompatActivity(),SensorEventListener{
 lateinit var gv:GLSurfaceView;lateinit var r:VrRenderer;lateinit var tr:HandTracker;lateinit var sm:SensorManager
 @Volatile var rotM=floatArrayOf(1f,0f,0f,0f,1f,0f,0f,0f,1f);val acc=floatArrayOf(0f,0f,9.8f);val lin=FloatArray(3);@Volatile var dispRot=1
 private val h=Handler(Looper.getMainLooper());private var lp:Runnable?=null;private var tx=0f;private var t0=0L;private var mv=0f

 @Suppress("DEPRECATION")
 private fun rot()=windowManager.defaultDisplay.rotation

 override fun onCreate(b:Bundle?){super.onCreate(b);Prefs.init(this);window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
  WindowCompat.setDecorFitsSystemWindows(window,false)
  WindowInsetsControllerCompat(window,window.decorView).let{it.hide(WindowInsetsCompat.Type.systemBars());it.systemBarsBehavior=WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE}
  sm=getSystemService(SENSOR_SERVICE) as SensorManager;dispRot=rot()
  r=VrRenderer(this);r.onReady={runOnUiThread{startTracking()}}
  gv=GLSurfaceView(this);gv.setEGLContextClientVersion(2);gv.setRenderer(r);setContentView(gv)
  tr=HandTracker(this){hs,ar,_->r.hands=hs;r.handAr=ar}
  gv.setOnTouchListener{_,e->touch(e);true}}

 private fun startTracking(){dispRot=rot()
  val pv=if(Prefs["mode"]==1)Preview.Builder().setTargetRotation(dispRot).build().also{p->
   val ex=ContextCompat.getMainExecutor(this)
   p.setSurfaceProvider(ex){rq->val st=r.st!!;st.setDefaultBufferSize(rq.resolution.width,rq.resolution.height);val s=Surface(st);rq.provideSurface(s,ex){s.release()}}} else null
  tr.start(this,dispRot,pv,false)}

 override fun onResume(){super.onResume();gv.onResume();dispRot=rot()
  val g=sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)?:sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
  for(s in listOfNotNull(g,sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)))sm.registerListener(this,s,SensorManager.SENSOR_DELAY_GAME)}
 override fun onPause(){super.onPause();sm.unregisterListener(this);tr.stop();gv.onPause()}
 override fun onSensorChanged(e:SensorEvent){when(e.sensor.type){
  Sensor.TYPE_GAME_ROTATION_VECTOR,Sensor.TYPE_ROTATION_VECTOR->{val m=FloatArray(9);SensorManager.getRotationMatrixFromVector(m,e.values);rotM=m}
  Sensor.TYPE_ACCELEROMETER->for(i in 0..2)acc[i]=e.values[i]
  Sensor.TYPE_LINEAR_ACCELERATION->for(i in 0..2)lin[i]=e.values[i]}}
 override fun onAccuracyChanged(s:Sensor?,a:Int){}
 fun toast(s:String){runOnUiThread{Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}}
 @Suppress("DEPRECATION") fun buzz(){(getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(15)}

 // тап — блок, удержание — очистка, два пальца — центр, свайп (акселерометр) — поворот
 private fun touch(e:MotionEvent){when(e.actionMasked){
  MotionEvent.ACTION_DOWN->{tx=e.x;t0=System.currentTimeMillis();mv=0f;lp=Runnable{gv.queueEvent{r.clear()};lp=null};h.postDelayed(lp!!,800)}
  MotionEvent.ACTION_POINTER_DOWN->{lp?.let{h.removeCallbacks(it)};lp=null;mv=999f;gv.queueEvent{r.recenter()}}
  MotionEvent.ACTION_MOVE->{val dx=e.x-tx;tx=e.x;mv+=abs(dx);if(Prefs["track"]==1)r.yawOff+=dx*.005f}
  MotionEvent.ACTION_UP->{lp?.let{h.removeCallbacks(it);lp=null;if(mv<20&&System.currentTimeMillis()-t0<400)gv.queueEvent{r.spawn()}}}}}
}
