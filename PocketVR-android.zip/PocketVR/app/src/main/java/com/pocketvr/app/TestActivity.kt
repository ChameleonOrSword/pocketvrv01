package com.pocketvr.app
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.min

class TestActivity:AppCompatActivity(){
 lateinit var tr:HandTracker
 @Suppress("DEPRECATION")
 override fun onCreate(b:Bundle?){super.onCreate(b);Prefs.init(this);window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
  val tv=TestView(this);val back=Button(this).apply{text="← Меню";setOnClickListener{finish()}}
  setContentView(FrameLayout(this).apply{addView(tv);addView(back)})
  tr=HandTracker(this){hs,_,bmp->tv.hands=hs;tv.bmp=bmp;tv.tr=tr;tv.postInvalidate()}
  tr.start(this,windowManager.defaultDisplay.rotation,null,true)}
 override fun onDestroy(){super.onDestroy();tr.stop()}
}
class TestView(c:Context):View(c){
 @Volatile var hands:List<Hand> = emptyList();@Volatile var bmp:Bitmap?=null;var tr:HandTracker?=null
 private val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{strokeWidth=3f;textSize=34f}
 override fun onDraw(c:Canvas){c.drawColor(Color.BLACK);val b=bmp?:return;val W=width.toFloat();val H=height.toFloat()
  val s=min(W/b.width,H/b.height);val w=b.width*s;val h=b.height*s;val ox=(W-w)/2;val oy=(H-h)/2
  c.save();if(Prefs["mirror"]==1)c.scale(-1f,1f,W/2,H/2)
  p.alpha=210;c.drawBitmap(b,null,RectF(ox,oy,ox+w,oy+h),p);p.alpha=255
  fun draw(a:FloatArray,col:Int,rad:Float){p.color=col
   for((i,j) in CONN)c.drawLine(ox+a[i*3]*w,oy+a[i*3+1]*h,ox+a[j*3]*w,oy+a[j*3+1]*h,p)
   for(i in 0 until 21)c.drawCircle(ox+a[i*3]*w,oy+a[i*3+1]*h,rad,p)}
  for(hd in hands){draw(hd.raw,0xFFFF3D5A.toInt(),5f);draw(hd.lm,0xFF19F0FF.toInt(),7f)}
  c.restore();p.color=0xFF19F0FF.toInt()
  c.drawText("FPS %.0f  задержка %.0f мс  рук %d   красный: сырой, голубой: сглаженный".format(tr?.fps?:0f,tr?.lat?:0f,hands.size),24f,H-24f,p)}
}
