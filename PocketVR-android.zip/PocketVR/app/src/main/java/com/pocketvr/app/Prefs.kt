package com.pocketvr.app
import android.content.Context
import android.content.SharedPreferences
object Prefs{
 lateinit var sp:SharedPreferences
 fun init(c:Context){sp=c.getSharedPreferences("pvr",0)}
 // mode 0=VR 1=MR | track 0=gyro 1=accel 2=6dof | hand 0..3 | shape 0 cube 1 sphere 2 mix | cam 0 back 1 front
 val def=mapOf("mode" to 0,"track" to 0,"hand" to 0,"shape" to 2,"cam" to 0,"turbo" to 1,"mirror" to 0,"smooth" to 60,"fov" to 80,"ipd" to 64)
 operator fun get(k:String):Int=sp.getInt(k,def[k]!!)
 operator fun set(k:String,v:Int){sp.edit().putInt(k,v).apply()}
}
